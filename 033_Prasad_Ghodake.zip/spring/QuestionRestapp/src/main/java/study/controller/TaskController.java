package study.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.annotation.RequestScope;

import study.dao.TaskDAO;
import study.entity.TaskEntity;

@RestController
@RequestMapping("/plan")
public class TaskController {
	
	@Autowired
	TaskDAO dao;
	
	@GetMapping("/allplans")
	public List<TaskEntity> show()
	{
		System.out.println("show call");
		List<TaskEntity> list= dao.showall();
		return list;
	}
	
	@PostMapping("/updatePlan/{id}/{is_done}")
	public void update(@PathVariable int id,@PathVariable boolean is_done)
	{
		dao.update(id, is_done);
	}

}
