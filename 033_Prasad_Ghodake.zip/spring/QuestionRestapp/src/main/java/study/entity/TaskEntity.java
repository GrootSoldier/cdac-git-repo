package study.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="planer_info_tbl")
public class TaskEntity 
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column
	private int id;
	@Column
	private String date;
	@Column
	private String task;
	@Column
	private boolean is_done=false;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getTask() {
		return task;
	}
	public void setTask(String task) {
		this.task = task;
	}
	public boolean isIs_done() {
		return is_done;
	}
	public void setIs_done(boolean is_done) {
		this.is_done = is_done;
	}
	@Override
	public String toString() {
		return "TaskEntity [id=" + id + ", date=" + date + ", task=" + task + ", is_done=" + is_done + "]";
	}
	public TaskEntity(int id, String date, String task, boolean is_done) {
		super();
		this.id = id;
		this.date = date;
		this.task = task;
		this.is_done = is_done;
	}
	public TaskEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	

}
