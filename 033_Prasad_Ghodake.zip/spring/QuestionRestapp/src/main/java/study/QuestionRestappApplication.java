package study;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuestionRestappApplication {

	public static void main(String[] args) {
		SpringApplication.run(QuestionRestappApplication.class, args);
	}

}
