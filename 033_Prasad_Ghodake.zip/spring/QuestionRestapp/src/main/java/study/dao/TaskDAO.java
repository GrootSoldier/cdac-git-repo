package study.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;

import study.entity.TaskEntity;
import study.repository.MyRepository;

@Service
public class TaskDAO 
{
	@Autowired
	MyRepository repo;
	

	public List<TaskEntity> showall()
	{
		System.out.println("showall call");
		return repo.findAll();
	}
	
	public void update(int id,boolean update)
	{
		TaskEntity te=repo.findById(id).get();
		te.setIs_done(update);
		repo.save(te);
		System.out.println("UPDATED");
		
	}
}
