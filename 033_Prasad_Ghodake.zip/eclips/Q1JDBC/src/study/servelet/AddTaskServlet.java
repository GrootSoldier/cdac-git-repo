package study.servelet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import study.dao.DBManager;


@WebServlet("/AddTaskServlet")
public class AddTaskServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String date=request.getParameter("date");
		String task=request.getParameter("task");
		
		DBManager dao=new DBManager();
		dao.add(date, task);
		response.getWriter().append("Task Added SUCCESSFULY ");
	}

}
