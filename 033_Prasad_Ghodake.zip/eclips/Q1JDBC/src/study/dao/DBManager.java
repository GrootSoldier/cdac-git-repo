package study.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DBManager 
{
	public void add(String date,String task)
	{
		try {
			
			Connection con=makeconnection();
			String sql="INSERT INTO PLANER_INFO_TBL(DATE,TASK) VALUES(?,?)";
			PreparedStatement pstmt=con.prepareStatement(sql);
			pstmt.setString(1, date);
			pstmt.setString(2, task);
			pstmt.executeUpdate();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

public Connection makeconnection() throws ClassNotFoundException, SQLException {
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		String url="jdbc:Mysql://localhost:3306/task_planer";
		String user="root";
		String password="root";
		
		Connection con=DriverManager.getConnection(url, user, password);
		
		return con;
	}

}
